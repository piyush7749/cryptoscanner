var margin = {
	top: 10,
	right: 10,
	bottom: 70,
	left: 90
},
width = 900 - margin.left - margin.right,
height = 490 - margin.top - margin.bottom;

var parseDate = d3.time.format("%Y-%m-%d").parse;
var x = d3.time.scale().range([0, width]);
var y = d3.scale.linear().range([height, 0]);
var xAxis = d3.svg.axis().scale(x).orient("bottom").ticks(d3.time.days, 1).tickFormat(d3.time.format("%Y-%m-%d"));
var yAxis = d3.svg.axis().scale(y).orient("left");

var color = d3.scale.category10();

var weekdays = new Array(7);
weekdays[0] = "Sunday";
weekdays[1] = "Monday";
weekdays[2] = "Tuesday";
weekdays[3] = "Wednesday";
weekdays[4] = "Thursday";
weekdays[5] = "Friday";
weekdays[6] = "Saturday";

var valueline = d3.svg.line()
	.x(function(d) {
	return x(d.dt);
})
	.y(function(d) {
	return y(d.sum_subs);
});

var valuelineMean = d3.svg.line()
	.x(function(d) {
	return x(d.dt);
})
	.y(function(d) {
	return y(d.mean);
});

var valuelineStdDev = d3.svg.line()
	.x(function(d) {
	return x(d.dt);
})
	.y(function(d) {
	return y(d.stddev);
});

var svg = d3.select("#segmentLineChart").append("svg")
	.attr("width", width + margin.left + margin.right)
	.attr("height", height + margin.top + margin.bottom)
	.append("g")
	.attr("transform", "translate(" + margin.left + "," + margin.top + ")");

var tip = d3.tip()
	.attr('class', 'd3-tip')
	.offset([-10, 0])
	.html(function(d) {
	return '<div class="tooltip-inner">' +
		'<span class="pull-left tooltip-label"><strong>' + getDateShortFormat(d.dt) + '</strong></span><br />' +
		'<span class="pull-left tooltip-label">Segment: </span>' +
		'<span class="pull-right"><strong>' + d.segment + '</strong></span><br />' +
		'<span class="pull-left tooltip-label">Num subs:&nbsp;</span>' +
		'<span class="pull-right"><strong> ' + addComma(d.sum_subs) + '</strong></span><br />' +
		'</div>';
});

function initLineChart(data) {

	data.forEach(function(d) {
		d.dt = parseDate(d.dt);
		d.sum_subs = +d.sum_subs;
	});

	data = data.sort(function(a, b) {
		return a.dt - b.dt
	});

	x.domain(d3.extent(data, function(d) {
		return d.dt;
	}));
	// y.domain(d3.extent(data, function(d) { return d.sum_subs; }));
	y.domain([0, d3.max(data, function(d) {
		return d.sum_subs;
	})]);

	svg.append("g")
		.attr("class", "x axis")
		.attr("transform", "translate(0," + height + ")")
		.call(xAxis)
		.selectAll(".tick text")
		.style("text-anchor", "end")
		.attr("dx", "-.8em")
		.attr("dy", "-.21em")
		.attr("transform", function(d) {
		return "rotate(-55)"
	});

	svg.append("g")
		.attr("class", "y axis")
		.call(yAxis)
		.append("text")
		.attr("transform", "rotate(-90)")
    .attr("class","y-text")
		.attr("y", 10 - margin.left)
		.attr("x", 35 - (height / 2))
		.attr("dy", ".71em")
		.style("text-anchor", "end")
		.text("Number of Subs");


	svg.append("path")
		.datum(data)
		.attr("class", "line")
		.attr("d", valueline);

	svg.append("path")
		.datum(data)
		.attr("class", "line-mean")
		.style("stroke-dasharray", ("3, 3"))
		.attr("d", valuelineMean);

	// add circles
	svg.append("g").selectAll("circle")
		.data(data)
		.enter()
		.append("circle")
		.attr("class", "points")
		.attr("r", 4)
		.attr("cx", function(d) {
		return x(d.dt)
	})
		.attr("cy", function(d) {
		return y(d.sum_subs)
	})
		.attr("fill", function(d) {

		if (d.anomalybool == 1) {
			return "red";
		} else {
			return "lightgrey";
		}

	})
		.attr("stroke", function(d) {

		if (d.anomalybool == 1) {
			return "red";
		} else {
			return "lightgrey";
		}
	})
		.on("mouseover", tip.show)
		.on("mouseout", tip.hide)
		.on('click', function(d){
					if (d.anomalybool == 1) {
						var url = "https://www.google.com/search?q=" + d.segment + "+" + getDateShort(d.dt);
						window.open(url);
					}
    	  });

	svg.call(tip);
}

function updateLineChart(data) {
	data.forEach(function(d) {
		d.sum_subs = +d.sum_subs;
		if (typeof d.dt == "string") {
			d.dt = parseDate(d.dt);
		}
	});

	data = data.sort(function(a, b) {
		return a.dt - b.dt
	});

	// Scale the range of the data again
	x.domain(d3.extent(data, function(d) {
		return d.dt;
	}));

	if (scaleType == "Extent Scale") y.domain(d3.extent(data, function(d) {
		return d.sum_subs;
	}));
	else y.domain([0, d3.max(data, function(d) {
		return d.sum_subs;
	})]);

	// Select the section we want to apply our changes to
	var svg = d3.select("#segmentLineChart");

	// Make the changes
	svg.select(".line") // change the line
	.transition().duration(1000)
		.attr("d", valueline(data));

	svg.select(".line-mean") // change the line
	.transition().duration(1000)
		.attr("d", valuelineMean(data));

	svg.select(".x.axis") // change the x axis
	.transition().duration(1000)
		.call(xAxis)
		.selectAll(".tick text")
		.style("text-anchor", "end")
		.attr("dx", "-.8em")
		.attr("dy", "-.21em")
		.attr("transform", function(d) {
		return "rotate(-55)"
	});
	svg.select(".y.axis") // change the y axis
	.transition().duration(1000)
		.call(yAxis);

	svg.selectAll(".points")
		.data(data)
		.transition().duration(1000)
		.attr("cx", function(d) {
		return x(d.dt);
	})
		.attr("cy", function(d) {
		return y(d.sum_subs);
	})
		.attr("fill", function(d) {
		if (d.anomalybool == 1) {
			return "red";
		} else {
			return "lightgrey";
		}
	})
		.attr("stroke", function(d) {
		if (d.anomalybool == 1) {
			return "red";
		} else {
			return "lightgrey";
		}
	});
}
