function getDateShortFormat(date) {
	// adding 1 to date.getMonth() since getMonth() method returns months from 0-11
	var weekday_value = date.getDay();
	var dateFormat = date.getMonth() + 1 + "-" + date.getDate() + "-" + date.getFullYear();
	return weekdays[weekday_value] + ",  " + dateFormat;
}

function getDateShort(date) {
	var dateFormat = date.getMonth() + 1 + "-" + date.getDate() + "-" + date.getFullYear();
	return dateFormat;
}

function addComma(str) {
	return str.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function loadingMask(){
	return {
		run: function(){
			console.log("Run called");
			$('#anomaliesTable').hide();
			$('#table-spinner').show();
		},
		stop: function(){
			console.log("Stop called");
			$('#anomaliesTable').show();
			$('#table-spinner').hide();
		}
	}
}
